<?php

namespace SShortener\Events;

abstract class Event
{
    //
}
